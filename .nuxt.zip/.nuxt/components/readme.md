# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<FarmingPanel>` | `<farming-panel>` (components/FarmingPanel.vue)
- `<StakingPanel>` | `<staking-panel>` (components/StakingPanel.vue)
- `<FarmingCard>` | `<farming-card>` (components/FarmingCard/farming-card.vue)
- `<Footer>` | `<footer>` (components/Footer/Footer.vue)
- `<Header>` | `<header>` (components/Header/Header.vue)
- `<MenuPanel>` | `<menu-panel>` (components/MenuPanel/MenuPanel.vue)
- `<MultipleSelectedTab>` | `<multiple-selected-tab>` (components/MultipleSelectTab/multiple-selected-tab.vue)
- `<StuffEmptyAnim>` | `<stuff-empty-anim>` (components/Stuff/EmptyAnim.vue)
- `<StuffLoading>` | `<stuff-loading>` (components/Stuff/Loading.vue)
- `<TabsTab>` | `<tabs-tab>` (components/Tabs/Tab.vue)
- `<Tabs>` | `<tabs>` (components/Tabs/Tabs.vue)
