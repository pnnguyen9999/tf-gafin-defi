export const FarmingPanel = () => import('../../components/FarmingPanel.vue' /* webpackChunkName: "components/farming-panel" */).then(c => wrapFunctional(c.default || c))
export const StakingPanel = () => import('../../components/StakingPanel.vue' /* webpackChunkName: "components/staking-panel" */).then(c => wrapFunctional(c.default || c))
export const FarmingCard = () => import('../../components/FarmingCard/farming-card.vue' /* webpackChunkName: "components/farming-card" */).then(c => wrapFunctional(c.default || c))
export const Header = () => import('../../components/Header/Header.vue' /* webpackChunkName: "components/header" */).then(c => wrapFunctional(c.default || c))
export const MenuPanel = () => import('../../components/MenuPanel/MenuPanel.vue' /* webpackChunkName: "components/menu-panel" */).then(c => wrapFunctional(c.default || c))
export const MultipleSelectedTab = () => import('../../components/MultipleSelectTab/multiple-selected-tab.vue' /* webpackChunkName: "components/multiple-selected-tab" */).then(c => wrapFunctional(c.default || c))
export const TabsTab = () => import('../../components/Tabs/Tab.vue' /* webpackChunkName: "components/tabs-tab" */).then(c => wrapFunctional(c.default || c))
export const Tabs = () => import('../../components/Tabs/Tabs.vue' /* webpackChunkName: "components/tabs" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
